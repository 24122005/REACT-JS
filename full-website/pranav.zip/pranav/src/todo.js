import React, { useState, useEffect } from 'react';
import './App.css';

function Todo() {
  const [movies, setMovies] = useState([]);
  const [movieTitle, setMovieTitle] = useState('');
  const [movieDirector, setMovieDirector] = useState('');
  const [releaseYear, setReleaseYear] = useState('');

  useEffect(() => {
    const storedMovies = JSON.parse(localStorage.getItem('movies'));
    if (storedMovies) {
      setMovies(storedMovies);
    }
  }, []);

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    if (name === 'movieTitle') {
      setMovieTitle(value);
    } else if (name === 'movieDirector') {
      setMovieDirector(value);
    } else if (name === 'releaseYear') {
      setReleaseYear(value);
    }
  };

  const addMovie = () => {
    if (movieTitle!== '' && movieDirector!== '' && releaseYear!== '') {
      const newMovie = {
        id: Date.now(),
        title: movieTitle,
        director: movieDirector,
        releaseYear: releaseYear
      };
      setMovies([...movies, newMovie]);
      setMovieTitle('');
      setMovieDirector('');
      setReleaseYear('');
      localStorage.setItem('movies', JSON.stringify([...movies, newMovie]));
    }
  };

  const deleteMovie = (id) => {
    const updatedMovies = movies.filter(movie => movie.id !== id);
    setMovies(updatedMovies);
    localStorage.setItem('movies', JSON.stringify(updatedMovies));
  };

  return (
    <div>
      <h1>Movie Collection</h1>
      <div>
        <input type="text" name="movieTitle" value={movieTitle} onChange={handleInputChange} placeholder="Movie Title" />
        <input type="text" name="movieDirector" value={movieDirector} onChange={handleInputChange} placeholder="Director" />
        <input type="text" name="releaseYear" value={releaseYear} onChange={handleInputChange} placeholder="Release Year" />
        <button onClick={addMovie}>Add Movie</button>
      </div>
      <ul>
        {movies.map(movie => (
          <li key={movie.id}>
            <div>Title: {movie.title}</div>
            <div>Director: {movie.director}</div>
            <div>Release Year: {movie.releaseYear}</div>
            <button onClick={() => deleteMovie(movie.id)}>Delete</button>
          </li>
        ))}
      </ul>
    </div>
  );
}

export default Todo;